package com.beastbot

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View
import com.beastbot.engine.Rules

/** يعرض لقطة الشاشة للمعايرة (زاويتان ثم لمس كل خانة لتحديد مستواها) أو معاينة اللوحة الحالية. */
class BoardView(ctx: Context, private val rules: Rules) : View(ctx) {
    var area: Rect? = null
    var levels = IntArray(rules.size * rules.size)
    private var bmp: Bitmap? = null
    private var corner: Point? = null
    private val line = Paint().apply { color = 0xFFD4AF37.toInt(); style = Paint.Style.STROKE; strokeWidth = 3f }
    private val txt = Paint().apply { color = Color.WHITE; textSize = 44f; textAlign = Paint.Align.CENTER; isAntiAlias = true }

    fun setShot(b: Bitmap, saved: Rect?) { bmp = b; area = saved; corner = null; levels = IntArray(levels.size); invalidate() }
    fun preview(l: IntArray) { bmp = null; levels = l; invalidate() }

    private fun scale() = bmp?.let { minOf(width.toFloat() / it.width, height.toFloat() / it.height) } ?: 1f
    private fun offX() = bmp?.let { (width - it.width * scale()) / 2 } ?: 0f
    private fun offY() = bmp?.let { (height - it.height * scale()) / 2 } ?: 0f

    private fun gridRect(): RectF? {
        if (bmp == null) { val s = minOf(width, height) - 8f; return RectF(4f, 4f, 4f + s, 4f + s) }
        val a = area ?: return null
        val s = scale()
        return RectF(offX() + a.left * s, offY() + a.top * s, offX() + a.right * s, offY() + a.bottom * s)
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(0xFF10102A.toInt())
        bmp?.let { val s = scale(); c.drawBitmap(it, null, RectF(offX(), offY(), offX() + it.width * s, offY() + it.height * s), null) }
        val g = gridRect() ?: return
        val n = rules.size; val cw = g.width() / n; val ch = g.height() / n
        for (i in 0..n) {
            c.drawLine(g.left, g.top + i * ch, g.right, g.top + i * ch, line)
            c.drawLine(g.left + i * cw, g.top, g.left + i * cw, g.bottom, line)
        }
        for (i in levels.indices) if (levels[i] != 0)
            c.drawText("${levels[i]}", g.left + (i % n + 0.5f) * cw, g.top + (i / n + 0.5f) * ch + 15f, txt)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (e.action != MotionEvent.ACTION_UP || bmp == null) return true
        val s = scale()
        val bx = ((e.x - offX()) / s).toInt(); val by = ((e.y - offY()) / s).toInt()
        val a = area
        if (a != null && a.contains(bx, by)) {
            val n = rules.size
            val i = ((by - a.top) * n / a.height()) * n + ((bx - a.left) * n / a.width())
            levels[i] = (levels[i] + 1) % (rules.maxLevel + 1)
        } else if (corner == null) {
            corner = Point(bx, by); area = null
        } else {
            val p = corner!!
            area = Rect(minOf(p.x, bx), minOf(p.y, by), maxOf(p.x, bx), maxOf(p.y, by)); corner = null
        }
        invalidate()
        return true
    }
}
