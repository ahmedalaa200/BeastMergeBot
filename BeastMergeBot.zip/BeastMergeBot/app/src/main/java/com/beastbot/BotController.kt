package com.beastbot

import android.graphics.Rect
import com.beastbot.engine.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive

enum class Mode { ANALYZE, STEP, AUTO }

class RunConfig(
    val rules: Rules = Rules(),
    val delayMs: Long = 700,
    val maxMoves: Int = 500,
    val minConfidence: Float = 0.6f,
)

/** حلقة: لقطة ← تعرّف ← تحقق من المتوقع ← حل ← سحبة واحدة ← انتظار. تتوقف عند أي شك. */
class BotController(
    private val svc: BotService,
    private val recognizer: Recognizer,
    private val cfg: RunConfig,
) {
    private val rules = cfg.rules
    private val solver = Solver(rules)
    val approvals = Channel<Unit>(Channel.CONFLATED)

    suspend fun run(mode: Mode, area: Rect) {
        var prev: Board? = null
        var prevDir: Dir? = null
        var moves = 0
        while (moves < cfg.maxMoves) {
            currentCoroutineContext().ensureActive()
            val (board, err) = readStable(area, prev, prevDir)
            if (board == null) { BotState.publish(UiState(null, null, moves, "توقف: $err")); return }
            val dir = solver.best(board)
            if (dir == null) { BotState.publish(UiState(board.cells, null, moves, "لا توجد حركات: انتهى الحدث")); return }
            BotState.publish(UiState(board.cells, dir, moves, "الحركة القادمة"))
            if (mode == Mode.ANALYZE) return
            if (mode == Mode.STEP) approvals.receive()
            if (!swipe(dir, area)) { BotState.publish(UiState(board.cells, dir, moves, "توقف: فشل تنفيذ الإيماءة")); return }
            prev = board; prevDir = dir; moves++
            delay(cfg.delayMs)
        }
        BotState.publish(UiState(null, null, moves, "وصلنا للحد الأقصى للحركات"))
    }

    private suspend fun readStable(area: Rect, prev: Board?, dir: Dir?): Pair<Board?, String?> {
        var why = ""
        repeat(4) {
            val shot = svc.screenshot() ?: return Pair(null, "فشل التقاط الشاشة (قد تمنعه اللعبة)")
            val rd = recognizer.read(shot, area, rules.size)
            val b = Board(rules.size, rd.levels)
            why = when {
                rd.confidence < cfg.minConfidence -> "ثقة التعرف منخفضة (${"%.2f".format(rd.confidence)})"
                prev != null && Verifier.explain(prev, dir!!, b, rules) is Verdict.Mismatch -> "اللوحة لا تطابق المتوقع بعد الحركة"
                else -> return Pair(b, null)
            }
            delay(450) // قد يكون الأنيميشن لم ينتهِ بعد
        }
        return Pair(null, why)
    }

    private suspend fun swipe(dir: Dir, a: Rect): Boolean {
        val cx = a.exactCenterX(); val cy = a.exactCenterY()
        val l = minOf(a.width(), a.height()) * 0.35f
        val (dx, dy) = when (dir) {
            Dir.UP -> Pair(0f, -l); Dir.DOWN -> Pair(0f, l)
            Dir.LEFT -> Pair(-l, 0f); Dir.RIGHT -> Pair(l, 0f)
        }
        return svc.swipe(cx - dx, cy - dy, cx + dx, cy + dy)
    }
}
