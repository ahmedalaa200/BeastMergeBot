package com.beastbot

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Path
import android.graphics.Rect
import android.view.Display
import android.view.accessibility.AccessibilityEvent
import com.beastbot.engine.TemplateClassifier
import kotlinx.coroutines.*
import kotlin.coroutines.resume

class BotService : AccessibilityService() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var controller: BotController? = null

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() { stopNow() }
    override fun onUnbind(intent: Intent?): Boolean { stopNow(); instance = null; return super.onUnbind(intent) }

    fun startRun(mode: Mode, area: Rect, classifier: TemplateClassifier, cfg: RunConfig) {
        stopNow()
        val c = BotController(this, Recognizer(classifier), cfg)
        controller = c
        job = scope.launch {
            BotState.publish(UiState(message = "انتقل إلى اللعبة: يبدأ بعد ٣ ثوانٍ"))
            delay(3000)
            c.run(mode, area)
        }
    }

    fun approveStep() { controller?.approvals?.trySend(Unit) }

    fun stopNow() {
        job?.cancel(); job = null
        BotState.publish(UiState(message = "تم الإيقاف"))
    }

    suspend fun screenshot(): Bitmap? = suspendCancellableCoroutine { cont ->
        takeScreenshot(Display.DEFAULT_DISPLAY, mainExecutor, object : TakeScreenshotCallback {
            override fun onSuccess(r: ScreenshotResult) {
                val hw = Bitmap.wrapHardwareBuffer(r.hardwareBuffer, r.colorSpace)
                val bmp = hw?.copy(Bitmap.Config.ARGB_8888, false)
                r.hardwareBuffer.close()
                cont.resume(bmp)
            }
            override fun onFailure(errorCode: Int) { cont.resume(null) }
        })
    }

    suspend fun swipe(x1: Float, y1: Float, x2: Float, y2: Float, durationMs: Long = 150): Boolean =
        suspendCancellableCoroutine { cont ->
            val path = Path().apply { moveTo(x1, y1); lineTo(x2, y2) }
            val g = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs)).build()
            val ok = dispatchGesture(g, object : GestureResultCallback() {
                override fun onCompleted(d: GestureDescription?) { cont.resume(true) }
                override fun onCancelled(d: GestureDescription?) { cont.resume(false) }
            }, null)
            if (!ok) cont.resume(false)
        }

    companion object { @Volatile var instance: BotService? = null }
}
