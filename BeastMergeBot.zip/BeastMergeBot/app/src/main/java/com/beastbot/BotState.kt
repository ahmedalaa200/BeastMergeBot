package com.beastbot

import com.beastbot.engine.Dir

class UiState(val levels: IntArray? = null, val dir: Dir? = null, val moves: Int = 0, val message: String = "")

object BotState {
    @Volatile var listener: ((UiState) -> Unit)? = null
    fun publish(s: UiState) { listener?.invoke(s) }
}
