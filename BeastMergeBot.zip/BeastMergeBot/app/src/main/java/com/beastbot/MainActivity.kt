package com.beastbot

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Rect
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.widget.*
import com.beastbot.engine.Dir
import com.beastbot.engine.Grid
import com.beastbot.engine.Rules
import kotlinx.coroutines.*

class MainActivity : Activity() {
    private val uiScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private val rules = Rules()
    private lateinit var boardView: BoardView
    private lateinit var status: TextView
    private lateinit var delayEdit: EditText
    private lateinit var maxEdit: EditText
    private var classifier = com.beastbot.engine.TemplateClassifier()
    private var shot: Bitmap? = null
    private var mode = Mode.ANALYZE

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        classifier = Store.loadTemplates(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0B0B1A.toInt()); setPadding(24, 24, 24, 24)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        status = TextView(this).apply { setTextColor(0xFFD4AF37.toInt()); textSize = 16f; text = "جاهز" }
        boardView = BoardView(this, rules)
        root.addView(status)
        root.addView(boardView, LinearLayout.LayoutParams(MATCH_PARENT, resources.displayMetrics.widthPixels))
        root.addView(btn("١. تفعيل خدمة الوصول") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) })
        root.addView(btn("٢. التقاط لقطة بعد ٥ ثوانٍ (انتقل للعبة ثم ارجع)") { captureLater() })
        root.addView(btn("٣. حفظ المعايرة والقوالب") { saveCalibration() })
        root.addView(btn("مسح القوالب") { classifier.clear(); Store.saveTemplates(this, classifier); status.text = "تم مسح القوالب" })

        val group = RadioGroup(this)
        listOf(1 to "تحليل فقط", 2 to "خطوة بخطوة", 3 to "تلقائي").forEach { (id, label) ->
            group.addView(RadioButton(this).apply { this.id = id; text = label; setTextColor(0xFFFFFFFF.toInt()) })
        }
        group.check(1)
        group.setOnCheckedChangeListener { _, id -> mode = when (id) { 1 -> Mode.ANALYZE; 2 -> Mode.STEP; else -> Mode.AUTO } }
        root.addView(group)

        delayEdit = edit("التأخير بين الحركات (مللي ثانية)", "700")
        maxEdit = edit("الحد الأقصى لعدد الحركات", "500")
        root.addView(delayEdit); root.addView(maxEdit)
        root.addView(btn("▶ ابدأ") { start() })
        root.addView(btn("⏭ التالي (خطوة بخطوة)") { BotService.instance?.approveStep() })
        root.addView(btn("⛔ إيقاف فوري") { BotService.instance?.stopNow() })
        setContentView(ScrollView(this).apply { addView(root) })
    }

    override fun onResume() {
        super.onResume()
        BotState.listener = { s -> runOnUiThread { render(s) } }
    }

    override fun onPause() { BotState.listener = null; super.onPause() }

    private fun render(s: UiState) {
        val arrow = when (s.dir) { Dir.UP -> "⬆"; Dir.DOWN -> "⬇"; Dir.LEFT -> "⬅"; Dir.RIGHT -> "➡"; null -> "–" }
        status.text = "${s.message}\nالحركة الحالية: $arrow | عدد الحركات: ${s.moves}"
        s.levels?.let { boardView.preview(it) }
    }

    private fun captureLater() {
        uiScope.launch {
            status.text = "انتقل للعبة الآن… لقطة بعد ٥ ثوانٍ"
            delay(5000)
            val s = BotService.instance?.screenshot()
            if (s == null) { status.text = "فشل الالتقاط: فعّل الخدمة أولًا، أو أن اللعبة تمنع لقطة الشاشة"; return@launch }
            shot = s
            boardView.setShot(s, Store.loadArea(this@MainActivity))
            status.text = "اضغط زاويتي اللوحة (أعلى-يسار ثم أسفل-يمين)، ثم المس كل خانة لتحديد مستواها (0 = فارغة)"
        }
    }

    private fun saveCalibration() {
        val a = boardView.area; val s = shot
        if (a == null || s == null) { status.text = "التقط لقطة وحدد اللوحة أولًا"; return }
        val rec = Recognizer(classifier)
        Grid.cells(a.left, a.top, a.right, a.bottom, rules.size).forEachIndexed { i, c ->
            classifier.add(boardView.levels[i], rec.signature(s, c[0], c[1], c[2], c[3]))
        }
        Store.saveArea(this, a); Store.saveTemplates(this, classifier)
        status.text = "تم الحفظ. المستويات المتعلَّمة: ${classifier.levels().sorted()}"
    }

    private fun start() {
        val a: Rect? = boardView.area ?: Store.loadArea(this)
        val svc = BotService.instance
        when {
            svc == null -> status.text = "فعّل خدمة الوصول أولًا"
            a == null -> status.text = "عاير اللوحة أولًا"
            classifier.levels().size < 2 -> status.text = "علّم القوالب أولًا (٣)"
            else -> svc.startRun(
                mode, a, classifier,
                RunConfig(rules, delayEdit.text.toString().toLongOrNull() ?: 700, maxEdit.text.toString().toIntOrNull() ?: 500),
            )
        }
    }

    private fun btn(t: String, f: () -> Unit) = Button(this).apply { text = t; setOnClickListener { f() } }
    private fun edit(h: String, v: String) = EditText(this).apply {
        hint = h; setText(v); inputType = android.text.InputType.TYPE_CLASS_NUMBER
        setTextColor(0xFFFFFFFF.toInt()); setHintTextColor(0xFF888888.toInt())
    }
}
