package com.beastbot

import android.graphics.Bitmap
import android.graphics.Color
import com.beastbot.engine.Grid
import com.beastbot.engine.TemplateClassifier

class Recognizer(val classifier: TemplateClassifier) {
    class Reading(val levels: IntArray, val confidence: Float)

    /** بصمة الخانة: الجزء الأوسط مصغّر إلى 8×8 بكسل RGB. */
    fun signature(bmp: Bitmap, l: Int, t: Int, r: Int, b: Int): FloatArray {
        val w = r - l; val h = b - t
        val x0 = (l + w * 0.15f).toInt().coerceIn(0, bmp.width - 2)
        val y0 = (t + h * 0.15f).toInt().coerceIn(0, bmp.height - 2)
        val cw = (w * 0.7f).toInt().coerceIn(1, bmp.width - x0)
        val ch = (h * 0.7f).toInt().coerceIn(1, bmp.height - y0)
        val small = Bitmap.createScaledBitmap(Bitmap.createBitmap(bmp, x0, y0, cw, ch), 8, 8, true)
        val px = IntArray(64)
        small.getPixels(px, 0, 8, 0, 0, 8, 8)
        return FloatArray(192) { i ->
            val p = px[i / 3]
            when (i % 3) { 0 -> Color.red(p); 1 -> Color.green(p); else -> Color.blue(p) } / 255f
        }
    }

    fun read(bmp: Bitmap, area: android.graphics.Rect, size: Int): Reading {
        val levels = IntArray(size * size)
        var minConf = 1f
        Grid.cells(area.left, area.top, area.right, area.bottom, size).forEachIndexed { i, c ->
            val (lvl, conf) = classifier.classify(signature(bmp, c[0], c[1], c[2], c[3]))
            levels[i] = lvl
            if (conf < minConf) minConf = conf
        }
        return Reading(levels, minConf)
    }
}
