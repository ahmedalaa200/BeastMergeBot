package com.beastbot

import android.content.Context
import android.graphics.Rect
import com.beastbot.engine.TemplateClassifier

object Store {
    private fun p(c: Context) = c.getSharedPreferences("bot", Context.MODE_PRIVATE)

    fun saveArea(c: Context, r: Rect) =
        p(c).edit().putString("area", "${r.left},${r.top},${r.right},${r.bottom}").apply()

    fun loadArea(c: Context): Rect? =
        p(c).getString("area", null)?.split(",")?.map { it.toInt() }?.let { Rect(it[0], it[1], it[2], it[3]) }

    fun saveTemplates(c: Context, t: TemplateClassifier) =
        p(c).edit().putString("templates", t.serialize()).apply()

    fun loadTemplates(c: Context): TemplateClassifier =
        TemplateClassifier.parse(p(c).getString("templates", "") ?: "")
}
