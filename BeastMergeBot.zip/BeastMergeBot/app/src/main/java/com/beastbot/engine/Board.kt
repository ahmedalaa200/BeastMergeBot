package com.beastbot.engine

enum class Dir { UP, DOWN, LEFT, RIGHT }

/**
 * قواعد الحدث في مكان واحد. القيم الافتراضية مستنتجة من الفيديو وليست مؤكدة بالكامل:
 *  - لوحة 4×4، والحيوانات تنزلق لآخر اللوحة، والدمج مرة واحدة لكل زوج في الحركة.
 *  - الوحش الجديد يظهر بمستوى 1 فقط (غيّر spawnWeights إذا لاحظت غير ذلك).
 *  - أعلى مستوى 11 (من رسالة الموقع). عدّله إذا اختلف.
 */
data class Rules(
    val size: Int = 4,
    val maxLevel: Int = 11,
    val spawnWeights: Map<Int, Double> = mapOf(1 to 1.0),
)

data class MoveResult(val board: Board, val gain: Int)

class Board(val size: Int, val cells: IntArray) {
    init { require(cells.size == size * size) { "حجم اللوحة غير صحيح" } }

    fun empties(): List<Int> = cells.indices.filter { cells[it] == 0 }

    fun put(index: Int, level: Int): Board {
        val c = cells.copyOf(); c[index] = level; return Board(size, c)
    }

    /** يرجع null إذا لم تغيّر الحركة اللوحة (حركة غير قانونية). */
    fun move(dir: Dir, rules: Rules): MoveResult? {
        val out = IntArray(cells.size)
        var gain = 0
        for (line in 0 until size) {
            val src = IntArray(size) { cells[index(dir, line, it)] }
            val (res, g) = slide(src, rules.maxLevel)
            gain += g
            for (p in 0 until size) out[index(dir, line, p)] = res[p]
        }
        return if (out.contentEquals(cells)) null else MoveResult(Board(size, out), gain)
    }

    fun isDead(rules: Rules): Boolean = Dir.values().all { move(it, rules) == null }

    private fun index(dir: Dir, line: Int, pos: Int): Int = when (dir) {
        Dir.LEFT -> line * size + pos
        Dir.RIGHT -> line * size + (size - 1 - pos)
        Dir.UP -> pos * size + line
        Dir.DOWN -> (size - 1 - pos) * size + line
    }

    override fun equals(other: Any?) = other is Board && size == other.size && cells.contentEquals(other.cells)
    override fun hashCode() = cells.contentHashCode()

    companion object {
        fun of(vararg v: Int): Board {
            var n = 1
            while (n * n < v.size) n++
            return Board(n, v.copyOf())
        }

        /** انزلاق خط واحد نحو البداية، مع دمج كل زوج متطابق مرة واحدة. */
        fun slide(line: IntArray, maxLevel: Int): Pair<IntArray, Int> {
            val nz = line.filter { it != 0 }
            val out = IntArray(line.size)
            var gain = 0; var w = 0; var k = 0
            while (k < nz.size) {
                if (k + 1 < nz.size && nz[k] == nz[k + 1] && nz[k] < maxLevel) {
                    out[w++] = nz[k] + 1; gain += nz[k] + 1; k += 2
                } else { out[w++] = nz[k]; k++ }
            }
            return Pair(out, gain)
        }
    }
}
