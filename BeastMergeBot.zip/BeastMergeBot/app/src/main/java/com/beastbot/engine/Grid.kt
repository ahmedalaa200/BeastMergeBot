package com.beastbot.engine

/** تقسيم مستطيل اللوحة إلى خانات (left, top, right, bottom). يتكيف مع أي حجم شاشة. */
object Grid {
    fun cells(left: Int, top: Int, right: Int, bottom: Int, size: Int): List<IntArray> =
        List(size * size) { i ->
            val r = i / size; val c = i % size
            intArrayOf(
                left + (right - left) * c / size, top + (bottom - top) * r / size,
                left + (right - left) * (c + 1) / size, top + (bottom - top) * (r + 1) / size,
            )
        }
}
