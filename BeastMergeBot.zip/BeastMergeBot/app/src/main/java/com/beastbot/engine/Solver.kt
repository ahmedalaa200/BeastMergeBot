package com.beastbot.engine

import kotlin.math.abs

/** Expectimax: أقصى قيمة على حركاتي، ومتوسط على مكان ومستوى الوحش العشوائي. */
class Solver(private val rules: Rules, private val depth: Int = 2, private val maxSamples: Int = 6) {

    fun best(board: Board): Dir? {
        var bestDir: Dir? = null
        var bestVal = Double.NEGATIVE_INFINITY
        for (d in Dir.values()) {
            val m = board.move(d, rules) ?: continue
            val v = m.gain * 3.0 + chance(m.board, depth)
            if (v > bestVal) { bestVal = v; bestDir = d }
        }
        return bestDir
    }

    private fun maxNode(b: Board, d: Int): Double {
        if (d == 0) return heuristic(b)
        var best = DEAD
        for (dir in Dir.values()) {
            val m = b.move(dir, rules) ?: continue
            best = maxOf(best, m.gain * 3.0 + chance(m.board, d))
        }
        return best
    }

    private fun chance(b: Board, d: Int): Double {
        val e = b.empties()
        if (e.isEmpty()) return heuristic(b)
        val sample = if (e.size <= maxSamples) e else List(maxSamples) { e[it * e.size / maxSamples] }
        val total = rules.spawnWeights.values.sum()
        var acc = 0.0
        for (i in sample) for ((lvl, w) in rules.spawnWeights) acc += (w / total) * maxNode(b.put(i, lvl), d - 1)
        return acc / sample.size
    }

    private fun heuristic(b: Board): Double {
        val n = b.size
        var h = b.empties().size * 12.0
        var maxL = 0
        for (r in 0 until n) for (c in 0 until n) {
            val v = b.cells[r * n + c]
            if (v == 0) continue
            maxL = maxOf(maxL, v)
            if (c + 1 < n) { val w = b.cells[r * n + c + 1]; if (w != 0) h += if (w == v) 8.0 else -0.5 * abs(w - v) }
            if (r + 1 < n) { val w = b.cells[(r + 1) * n + c]; if (w != 0) h += if (w == v) 8.0 else -0.5 * abs(w - v) }
        }
        if (listOf(0, n - 1, n * (n - 1), n * n - 1).any { b.cells[it] == maxL }) h += maxL * 6.0
        return h
    }

    private companion object { const val DEAD = -1e6 }
}
