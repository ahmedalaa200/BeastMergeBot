package com.beastbot.engine

/** تصنيف الخانة بأقرب قالب لوني. الثقة = مدى تفوق أفضل مستوى على ثاني أفضل مستوى. */
class TemplateClassifier {
    private val templates = mutableMapOf<Int, MutableList<FloatArray>>()

    fun add(level: Int, sig: FloatArray) { templates.getOrPut(level) { mutableListOf() }.add(sig) }
    fun clear() = templates.clear()
    fun levels(): Set<Int> = templates.keys

    fun classify(sig: FloatArray): Pair<Int, Float> {
        if (templates.isEmpty()) return Pair(0, 0f)
        val sorted = templates.mapValues { (_, l) -> l.minOf { diff(it, sig) } }.entries.sortedBy { it.value }
        val best = sorted[0]
        val conf = when {
            best.value > MAX_DIST -> 0f
            sorted.size == 1 -> 1f - best.value / MAX_DIST
            else -> ((sorted[1].value - best.value) / (sorted[1].value + 1e-6f)).coerceIn(0f, 1f)
        }
        return Pair(best.key, conf)
    }

    private fun diff(a: FloatArray, b: FloatArray): Float {
        if (a.size != b.size) return Float.MAX_VALUE
        var s = 0f
        for (i in a.indices) s += kotlin.math.abs(a[i] - b[i])
        return s / a.size
    }

    fun serialize(): String = templates.entries.joinToString("\n") { (l, list) ->
        list.joinToString("\n") { "$l:" + it.joinToString(",") }
    }

    companion object {
        const val MAX_DIST = 0.25f
        fun parse(text: String): TemplateClassifier {
            val t = TemplateClassifier()
            text.lines().filter { it.contains(':') }.forEach { line ->
                val (l, v) = line.split(':', limit = 2)
                t.add(l.toInt(), v.split(',').map { it.toFloat() }.toFloatArray())
            }
            return t
        }
    }
}
