package com.beastbot.engine

data class Spawn(val index: Int, val level: Int)

sealed class Verdict {
    data class Match(val spawn: Spawn) : Verdict()
    data class Mismatch(val reason: String) : Verdict()
}

/** يقارن اللوحة الفعلية بعد الحركة بالمتوقعة: يجب أن يختلف خانة واحدة فقط (الوحش الجديد). */
object Verifier {
    fun explain(prev: Board, dir: Dir, actual: Board, rules: Rules): Verdict {
        val moved = prev.move(dir, rules) ?: return Verdict.Mismatch("الحركة غير قانونية")
        val diff = actual.cells.indices.filter { actual.cells[it] != moved.board.cells[it] }
        if (diff.size != 1) return Verdict.Mismatch("عدد الفروق ${diff.size} بدل 1")
        val i = diff[0]
        val lvl = actual.cells[i]
        if (moved.board.cells[i] != 0) return Verdict.Mismatch("تغيّرت خانة غير فارغة")
        if (lvl !in rules.spawnWeights.keys) return Verdict.Mismatch("ظهر وحش بمستوى $lvl غير موجود في القواعد")
        return Verdict.Match(Spawn(i, lvl))
    }
}
