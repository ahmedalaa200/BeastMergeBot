package com.beastbot

import com.beastbot.engine.*
import org.junit.Assert.*
import org.junit.Test

class EngineTest {
    private val rules = Rules()

    private fun board(vararg tiles: Pair<Int, Int>): Board {
        val c = IntArray(16)
        tiles.forEach { (i, l) -> c[i] = l }
        return Board(4, c)
    }

    @Test fun slideMergesEachPairOnce() {
        val (r, g) = Board.slide(intArrayOf(1, 1, 1, 1), 11)
        assertArrayEquals(intArrayOf(2, 2, 0, 0), r)
        assertEquals(4, g)
    }

    @Test fun slideDoesNotChainMerge() {
        assertArrayEquals(intArrayOf(2, 2, 0, 0), Board.slide(intArrayOf(1, 1, 2, 0), 11).first)
    }

    @Test fun slideSkipsGaps() {
        assertArrayEquals(intArrayOf(2, 0, 0, 0), Board.slide(intArrayOf(0, 1, 0, 1), 11).first)
    }

    @Test fun maxLevelDoesNotMerge() {
        assertArrayEquals(intArrayOf(11, 11, 0, 0), Board.slide(intArrayOf(11, 11, 0, 0), 11).first)
    }

    @Test fun movesInAllFourDirections() {
        val b = board(6 to 3) // صف 1، عمود 2
        assertEquals(3, b.move(Dir.LEFT, rules)!!.board.cells[4])
        assertEquals(3, b.move(Dir.RIGHT, rules)!!.board.cells[7])
        assertEquals(3, b.move(Dir.UP, rules)!!.board.cells[2])
        assertEquals(3, b.move(Dir.DOWN, rules)!!.board.cells[14])
    }

    @Test fun illegalMoveReturnsNull() {
        val b = board(0 to 1)
        assertNull(b.move(Dir.LEFT, rules))
        assertNull(b.move(Dir.UP, rules))
        assertNotNull(b.move(Dir.RIGHT, rules))
    }

    @Test fun detectsDeadBoard() {
        val cells = IntArray(16) { if ((it / 4 + it % 4) % 2 == 0) 1 else 2 }
        val b = Board(4, cells)
        assertTrue(b.isDead(rules))
        assertNull(Solver(rules).best(b))
    }

    @Test fun solverReturnsTheOnlyLegalMove() {
        val b = board(0 to 1, 4 to 2, 8 to 1, 12 to 2) // عمود كامل لا يندمج
        assertEquals(Dir.RIGHT, Solver(rules).best(b))
    }

    @Test fun solverAlwaysReturnsLegalMove() {
        val b = board(0 to 1, 1 to 1, 5 to 2, 10 to 3)
        val d = Solver(rules).best(b)
        assertNotNull(d)
        assertNotNull(b.move(d!!, rules))
    }

    @Test fun verifierAcceptsExpectedSpawn() {
        val prev = board(0 to 1)
        val actual = board(3 to 1, 5 to 1)
        assertEquals(Verdict.Match(Spawn(5, 1)), Verifier.explain(prev, Dir.RIGHT, actual, rules))
    }

    @Test fun verifierDetectsFailedExecution() { // السحبة لم تُنفَّذ: اللوحة لم تتغير
        val prev = board(0 to 1)
        assertTrue(Verifier.explain(prev, Dir.RIGHT, prev, rules) is Verdict.Mismatch)
    }

    @Test fun verifierDetectsMissingOrUnknownSpawn() {
        val prev = board(0 to 1)
        assertTrue(Verifier.explain(prev, Dir.RIGHT, board(3 to 1), rules) is Verdict.Mismatch)
        assertTrue(Verifier.explain(prev, Dir.RIGHT, board(3 to 1, 5 to 3), rules) is Verdict.Mismatch)
    }

    @Test fun classifierSeparatesLevelsAndRejectsUnknown() {
        val t = TemplateClassifier()
        t.add(1, FloatArray(192) { 0.1f }); t.add(2, FloatArray(192) { 0.9f })
        val (lvl, conf) = t.classify(FloatArray(192) { 0.12f })
        assertEquals(1, lvl); assertTrue(conf > 0.8f)
        assertEquals(0f, t.classify(FloatArray(192) { 0.5f }).second, 0f) // ثقة منخفضة ← لا تنفيذ
    }

    @Test fun classifierSerializationRoundTrip() {
        val t = TemplateClassifier(); t.add(4, FloatArray(192) { it / 192f })
        assertEquals(setOf(4), TemplateClassifier.parse(t.serialize()).levels())
    }

    @Test fun gridScalesWithAnyScreenSize() {
        val c = Grid.cells(100, 200, 500, 600, 4)
        assertArrayEquals(intArrayOf(100, 200, 200, 300), c[0])
        assertArrayEquals(intArrayOf(400, 500, 500, 600), c[15])
        val big = Grid.cells(200, 400, 1000, 1200, 4) // نفس اللوحة بضعف الدقة
        assertArrayEquals(intArrayOf(800, 1000, 1000, 1200), big[15])
    }
}
